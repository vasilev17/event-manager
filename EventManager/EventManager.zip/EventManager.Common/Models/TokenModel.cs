﻿namespace EventManager.Common.Models
{
    public record TokenModel(string Token);
}
