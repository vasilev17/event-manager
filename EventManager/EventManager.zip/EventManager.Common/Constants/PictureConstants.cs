﻿namespace EventManager.Common.Constants
{
    public static class PictureConstants
    {
        public const string DefaultUserPicture = "DefaultUserPicture";
        public const string DefaultEventPicture = "DefaultEventPicture";
    }
}
