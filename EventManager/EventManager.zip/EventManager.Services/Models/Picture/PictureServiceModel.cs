﻿namespace EventManager.Services.Models.Picture
{
    public class PictureServiceModel
    {
        public string Url { get; set; }

        public string ResourceType { get; set; }

        public string PublicId { get; set; }
    }
}
