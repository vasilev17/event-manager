﻿namespace EventManager.Services.Models.User
{
    public class ResetPasswordServiceModel
    {
        public required string Email { get; set; }
    }
}
