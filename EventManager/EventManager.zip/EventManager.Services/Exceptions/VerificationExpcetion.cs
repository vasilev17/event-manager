﻿namespace EventManager.Services.Exceptions
{
    public class VerificationExpcetion : Exception
    {
        public VerificationExpcetion() { }

        public VerificationExpcetion(string message) : base(message) { }
    }
}
