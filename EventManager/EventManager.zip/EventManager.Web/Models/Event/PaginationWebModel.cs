﻿namespace EventManager.Web.Models.Event
{
    public class PaginationWebModel
    {
       // public Guid LastEventId { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
    }
}
