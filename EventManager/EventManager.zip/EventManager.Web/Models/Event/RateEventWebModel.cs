﻿namespace EventManager.Web.Models.Event
{
    public class RateEventWebModel
    {
        public Guid UserId { get; set; }
        public float RatingValue { get; set; }
        
    }
}
