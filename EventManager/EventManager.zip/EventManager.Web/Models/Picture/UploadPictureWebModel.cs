﻿namespace EventManager.Web.Models.Picture
{
    public class UploadPictureWebModel
    {
        public IFormFile? Picture { get; set; }
    }
}
