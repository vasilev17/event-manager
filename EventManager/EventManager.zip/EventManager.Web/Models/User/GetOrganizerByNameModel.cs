﻿namespace EventManager.Web.Models.User
{
    public class GetOrganizerByNameModel
    {
        public string Name { get; set; }
    }
}
