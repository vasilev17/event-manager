﻿namespace EventManager.Web.Models.User
{
    public class VerificationRequestWebModel
    {
        public string? Description { get; set; }
    }
}
