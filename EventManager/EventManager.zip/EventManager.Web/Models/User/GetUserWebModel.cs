﻿namespace EventManager.Web.Models.User
{
    public class GetUserWebModel
    {
        public string UserName { get; set; } 
    }
}
